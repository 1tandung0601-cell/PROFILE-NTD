a,b,c=map(int,input().split())
if a+b>c and a+c>b and b+c>a:
    v=(a+b+c)/2
    s=(v*(v-a)*(v-b)*(v-c))**0.5
    print(s)
else:
    print("khong phai tam giac")