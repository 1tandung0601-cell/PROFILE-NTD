x=input()
n=int(input())
c=ord(x)+n
if c>=65 and c<=90:
    print(chr(c))
elif c>=97 and c<=122:
    print(chr(c))
else:
    print("khong thoa man")
