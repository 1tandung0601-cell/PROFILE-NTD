import math
from math import sqrt
n=int(input())
x=int(math.sqrt(n)+1)
for i in range(1,x):
    print (i*i,end=" ")