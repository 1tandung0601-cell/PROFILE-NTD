for i in range(1,37):
    if i*2+(36-i)*4==100:
        print("ga:",i,"cho:",36-i,end=" ")